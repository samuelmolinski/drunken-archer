<? $this->pageTitle=Yum::t('Messages'); ?>

<h1><? echo $title; ?></h1>

<div class="form">
<? echo $content; ?>

</div><!-- yiiForm -->
