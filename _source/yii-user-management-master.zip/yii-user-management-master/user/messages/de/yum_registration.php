<?
return array(
	'Your account has been activated' => 'Ihr Zugang wurde aktiviert',
	'Activation did not work' => 'Die Aktivierung ist fehlgeschlagen',
	'The user is already activated' => 'Der Benutzer ist bereits aktiviert',
	'Wrong activation Key' => 'Falscher Aktivierungsschlüssel',
	'Instructions have been sent to you. Please check your email.' => 'Ihnen wurde eine E-Mail mit einem Aktivierungslink zugesendet. Bitte überprüfen Sie Ihr E-Mail Postfach. '
);
?>
