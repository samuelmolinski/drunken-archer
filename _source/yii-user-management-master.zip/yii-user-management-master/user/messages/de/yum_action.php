<? return array(
'Manage Actions' => 'Aktionen verwalten',
'Create Action' => 'Aktion hinzufügen',
);
?>
