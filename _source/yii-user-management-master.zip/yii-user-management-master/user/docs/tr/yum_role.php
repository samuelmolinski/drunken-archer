<?
return array(
'Create role' => 'إنشاء تصنيف مستخدمين',
'Save role' => 'حفظ التصنيف',
'Is membership possible' => 'هل الإشتراك مسموح به ؟',
'Assign this role to new users automatically' => 'أضف  تصنيف مستخدمين الي الأعضاء الجدد تلقائياً',
'Searchable' => 'قابل للبحث',
'When selecting searchable, users of this role can be searched in the "user Browse" function' => 'لدي إختيار قابل للبحث, جميع الأعضاء التابعين لهذا التصنيف تظهر بياناتهم في  نتائج "البحث عن الأعضاء"',
'Manage roles' => 'إدارة  تصنيف مستخدمين',
'These users have a ordered memberships of this role' => 'هذا المستخدم يطلب إشتراك في هذا التصنيف',
	'Price' => 'السعر',
	'Duration in days' => 'الفترة الزمنية بالأيام',
	'How expensive is a membership?' => 'ماهو سعر الإشتراك؟',
'How many days will the membership be valid after payment?' => 'ماهو عدد الأيام المسموح بها للسعر المدفوع؟',
	'Selectable on registration' => 'قابل للإختيار عند التسجيل',
	'Update role' => 'تحديث تصنيف المستخدمين',
);
?>
