<?
return array(
'Let the user choose in privacy settings' => 'اسمح للمستخدم بالاختيار في إعدادات الخصوصية'
);
?>
