<?
return array(
		'Log profile visits' => 'سجل زيارات البروفايل',
		'Do not show the owner of a profile when i visit him' => 'عدم عرض مالك البروفايل خلال زيارتي له',
		'Show the owner when i visit his profile' => 'عرض مالك البروفايل لدي زيارتي له ',
		'Select the fields that should be public' => 'إختر الحقول التي تظهر للجميع',
		'Show online status' => 'أعرض حالة المتصلين',
		'Do not show my online status' => 'لا تعرض حالة إتصالي',
		'Show my online status to everyone' => 'إعرض حالة إتصالي للجميع',

		'Show friends' => 'إعرض الأصدقاء',
		'friends only' => 'الأصدقاء فقط',
		'do not make my friends public' => 'لا تظهر أصدقائي للجميع',
		'only to my friends' => 'فقط لإصدقائي',
		'make my friends public' => 'أعرض أصدقائي للجميع',
		'Your privacy settings have been saved' => 'تم حفظ إعدادات الخصوصية الخاصة بك',
		'Profile field public options' => 'خيارات حقل البروفايل العامة',
		'no' => 'لا',
		'yes' => 'نعم',
		'Make {field} public available' => 'إجعل {field} متاح للعامة',
		'Let me appear in the search' => 'إجعلني متاحا في البحث',
		'Do not appear in search' => 'عدم الظهور في البحث',
		'Appear in search' => 'الظهور في البحث',
		'Privacy settings for {username}' => 'إعدادات الخصوصية ل {username}',
		'Privacysettings' => 'إعدادات الخصوصية',
);

