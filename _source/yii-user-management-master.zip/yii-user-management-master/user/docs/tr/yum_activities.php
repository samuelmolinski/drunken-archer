<? return array(
	'Activities' => 'النشاطات',
	'Show activities' => 'عرض النشاطات',
	'of user' => 'الخاصة بالمستخدم',
	'All' => 'جميع',
);
?>
