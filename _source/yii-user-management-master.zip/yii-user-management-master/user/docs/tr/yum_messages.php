<?
return array(
		'Compose new message' => 'اكتب رسالة جديدة',
		'Composing new message' => 'إعداد رسالة جديدة',
		'Compose' => 'إعداد',
		'Message from' => 'رسالة من',
		'Message' => 'رسالة',
		'Content' => 'المحتوي',
		'Title' => 'العنوان',
		'Subject' => 'الموضوع',
		'Your friendship request has been accepted' => 'تم قبول صداقتك',
		'New friendship request from {username}' => 'طلب صداقة جديد من {username}',
		'One of the recipients ({username}) has ignored you. Message will not be sent!' => 'أحد المستخدمين One of the recipients ({username}) تجاهلك، لذا لا يمكن إرسال الرسالة',
		);
?>
