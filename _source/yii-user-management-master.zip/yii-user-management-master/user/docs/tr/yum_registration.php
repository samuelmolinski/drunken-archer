<?
return array(
	'Instructions have been sent to you. Please check your email.' => 'تم إرسال التعليمات إليك ... الرجاء مراجعة بريدك الإلكتروني '
);
?>
