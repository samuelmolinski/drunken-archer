<?
return array(
		'Are you sure you want to remove this friend?' => 'هل أنت متأكد من رغبتك في إزالة هذا الصديق',
		'Friendship rejected' => 'تم رفض طلب الصداقة',
		'Please enter a request Message up to 255 characters' => 'الرجاء كتابة رسالة لطلب الصداقة علي ان لا تزيد علي 255 حرف',
		'Friendship request for {username} has been sent' => 'تم إرسال طلب الصداقة ل {username}',
		'Friendship request already sent' => 'تم إرسال طلب الصداقة مسبقاً',
		'You already are friends' => 'انتم أصدقاء مسبقاً',
		'Friendship request has been rejected' => 'تم رفض طلب الصداقة',
		'Add as a friend' => 'إضافة كصديق',
		'New friendship request from {username}' => 'طلب صداقة جديد من {username}',
		'Friends' => 'أصدقاء',
		'friends only' => 'أصدقاء فقط',
		'Cancel request' => 'إلغاء الطلب',
);
?>
