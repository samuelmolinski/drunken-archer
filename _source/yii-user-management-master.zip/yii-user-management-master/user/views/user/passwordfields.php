<div class="row">
<? echo CHtml::activeLabelEx($form,'password'); ?>
<? echo CHtml::activePasswordField($form,'password'); ?>
</div>

<div class="row">
<? echo CHtml::activeLabelEx($form,'verifyPassword'); ?>
<? echo CHtml::activePasswordField($form,'verifyPassword'); ?>
</div>

