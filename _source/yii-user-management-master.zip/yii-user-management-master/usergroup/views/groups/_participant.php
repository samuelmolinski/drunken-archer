<? $this->renderPartial('application.modules.user.views.user._view', array(
			'data' => $data)); ?>

