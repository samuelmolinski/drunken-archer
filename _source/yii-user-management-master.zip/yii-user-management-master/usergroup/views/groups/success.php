<p> The Usergroup <? echo $model; ?> has been successfully created </p>

<? echo CHtml::Button(Yii::t('app', 'Back'), array('id' => $relation.'_done')); ?><? echo CHtml::Button(Yii::t('app', 'Add another Usergroup'), array('id' => $relation.'_create'));
