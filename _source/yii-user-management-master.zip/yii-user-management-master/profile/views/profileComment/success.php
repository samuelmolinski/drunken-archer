<h3> <? echo Yum::t('The comment has been saved'); ?> </h3>

<? echo CHtml::Button(Yum::t('Back'), array('onclick' => 'window.location.reload()')); ?>
