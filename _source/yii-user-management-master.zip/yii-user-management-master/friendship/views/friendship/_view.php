<?
	printf('<h2>%s</h2>', $data->invited->username);
?>
